
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('0.0.0.0', 8080))
s.listen(5)

#conn, addr = s.accept() 
conn = s.makefile('rw')


while True:
    data = conn.readline()
    if not data: 
    	print "Waited 5 second"
        break

    if data.strip() == "quit":
    	conn.shutdown(socket.SHUT_WR)
    	break

    # Parrot the data back to the client. 
    print "RECV:", data, data == "quit"
    conn.write("RET: " + data) 

s.close() 
