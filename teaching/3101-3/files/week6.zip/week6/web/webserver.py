import socket
import os.path

s = socket.socket(socket.AF_INET , socket.SOCK_STREAM) 
s.bind(('0.0.0.0', 8080))

s.listen(1) # Set socket to 'listening' state

while True:
	conn, addr = s.accept() 
	cfile = conn.makefile('rw') 
	l = cfile.readline()

	print "RECV:", l

	if l.startswith("GET "):
		pathname = os.path.join("jikk_web/", l.split()[1][1:])

	try:
		cfile.write('HTTP/1.0 200 OK\n\n') 
		cfile.write(open(pathname ,'r').read())
	except IOError:
		cfile.write('HTTP/1.0 404 Not Found\n\n') 
		cfile.write('Not found!')
	finally: 
		cfile.close()

conn.close()