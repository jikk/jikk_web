def func_trace(func):
    # New function object wraps fun 
    def new_fun(*args, **kwargs):
       # Before fun is called    
       print "calling with", args, kwargs
       result = func(*args, **kwargs) # Call fun 
       # After fun is called 
       print "return value", result
       return result
    return new_fun

import logging


# note that this decorator ignores **kwargs
def memoize(func):
    cache =  {}
    def memoizer(*args, **kwargs):
        if args not in cache:
            cache[args] = func(*args, **kwargs)
        return cache[args]
    return memoizer

@memoize
def factorial(n):
    print "#",
    return 1 if n == 1 else n * factorial(n - 1)



def singleton(cls):
  instances = {}
  def getinstance(*args, **kwargs):
    if cls not in instances:
        instances[cls] = cls(*args, **kwargs)
    return instances[cls]
  return getinstance