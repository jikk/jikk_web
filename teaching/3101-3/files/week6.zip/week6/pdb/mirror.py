import sys

def mirror(lst):
  ret = []
  for i in range(len(lst)):
    ret.append(lst[-i - 1])
  return lst + ret

if __name__ == '__main__':
  print mirror(sys.argv)
