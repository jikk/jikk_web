#!/usr/bin/python 

response = 
'''Content -Type: text/html
<html> <body>
<h1> Hello World </h1> </body>
</html>'''

print response