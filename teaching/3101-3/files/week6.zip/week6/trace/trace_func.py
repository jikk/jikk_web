def func_trace0(func):
    # New function object wraps fun 
    def new_fun(arg0):
       # Before fun is called    
       print "calling with", arg0
       result = func(arg0) # Call fun 
       # After fun is called 
       print "return value", result
       return result
    return new_fun



def func_trace1(func):
    # New function object wraps fun 
    def new_fun(*args, **kwargs):
       # Before fun is called    
       print "calling with", args, kwargs
       result = func(*args, **kwargs) # Call fun 
       # After fun is called 
       print "return value", result
       return result
    return new_fun

import logging

def func_trace2(func):
    # New function object wraps fun 
    def new_fun(*args, **kwargs):
       # Before fun is called    
       logging.debug("Calling with {0} {1}".format(args, kwargs))
       result = func(*args, **kwargs) # Call fun 
       # After fun is called 
       logging.debug("return value {0}".format(result))
       return result
    return new_fun


