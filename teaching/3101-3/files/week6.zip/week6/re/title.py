import re
import unittest

pat = r"<title\s*>(.*)</title\s*>"

title_txt = "this is a title"

title_lst =[ 
	"<title>{0}</title>".format(title_txt)
#	,"<TITLE>{0}</TITLE>".format(title_txt)	
#	,"<TITLE   >{0}</TITLE   >".format(title_txt)	

	]


class testRE(unittest.TestCase):

	def testTitle(self):
		for title_tag in title_lst:
			print "processing: ", title_tag

			m = re.search(pat, title_tag)
			#expect to see match 
			self.assertNotEqual(m, None)
			self.assertEqual(m.group(1), title_txt)


if __name__ == "__main__":
	unittest.main()