import re
import unittest

#pat = r"<a\s*href=\s*'(.*)'"
pat = r"<a\s*href=\s*('(.*)'|\"(.*)\")"
pat = r"<a\s*href=\s*('(.*?)'|\"(.*?)\")"



url_lst =[ 
	"<A Href= 'HTTP://s1.s2.DOMAIN.EDU:80/~usr/script.cgi?foo=bar&answer=4'>"
	, '<A Href= "HTTP://s1.s2.DOMAIN.EDU:80/~usr/script.cgi?foo=bar&answer=4">'
	, '<A Href= "teaching/index.html" target="_blank">'
	]


class testRE(unittest.TestCase):

	def testurl(self):
		for url_tag in url_lst:
			print "processing: ", url_tag

			m = re.search(pat, url_tag, re.I)
			#expect to see match 
			self.assertNotEqual(m, None)
			print m.groups()


if __name__ == "__main__":
	unittest.main()