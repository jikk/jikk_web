#!/usr/bin/env python
import csv
import sqlite3

if __name__ == "__main__":

	conn = sqlite3.connect("farmers.db")
	cursor = conn.cursor()

	create_table = """
	create table farmers_market(
		fmid INT PRIMARY KEY,
		name VARCHAR(100),
		zip VARCHAR(20),
		x FLOAT,
		y FLOAT
	)
	"""

	cursor.execute(create_table)


	insert_into = """
		insert into farmers_market values (?, ?, ?, ?, ?)
	"""

	cursor.execute(insert_into, (0, 'market a', '10027', 0.0, 0.0))

	f = open("markets.csv", "r")
	creader = csv.reader(f)

	for entry in creader:
		fmid = int(entry[0])
		name = entry[1]
		zipc = entry[7]
		x = float(entry[8])
		y = float(entry[9])

		cursor.execute(insert_into, (fmid, name, zipc, x, y))
	f.close()

	cursor.execute("SELECT * FROM farmers_market")
	for entry in cursor:
		print entry

	conn.commit()
	conn.close()


