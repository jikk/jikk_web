create table farmers_market(
	fmid INT PRIMARY KEY,
	name VARCHAR(100),
	addr1 VARCHAR(100),
	addr2 VARCHAR(100),
	city VARCHAR(100),
	county VARCHAR(100),
	state VARCHAR(100),
	zip VARCHAR(20),
	x FLOAT,
	y FLOAT
);

insert into farmers_market values(
	0,
	'market a',
	'1214 Amstredam',
	'',
	'New York',
	'',
	'NY',
	'10027',
	-70.0,
	80.0
);