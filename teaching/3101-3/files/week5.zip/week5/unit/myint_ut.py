#!/usr/bin/env python
import unittest

class Number(object):
    """
    """
    def __init__(self, value=0):
        """
        """
        self.value = value

    def __repr__(self):
        """
        """
        return str(self.value)

    def __str__(self):
        """
        """
        return str(self.value)


class Conversion(object):
    """
    """
    def __init__(self, value=0):
        """
        """
        self.value = value

    def to_binary(self):
        """
        get binary representation
        """
        return bin(self.value)

    def to_hex(self):
        """
        get hexadecimal representation
        """        
        return hex(self.value)


class MyInt(Number, Conversion):
    def __init__(self, value=0):
        Number.__init__(self, value)
        Conversion.__init__(self, value)

    def __add__(self, other):
        return MyInt(self.value + other.value)

    def __sub__(self, other):
        return MyInt(self.value - other.value)

    def __mul__(self, other):
        return MyInt(self.value * other.value)

    def __div__(self, other):
        return MyInt(self.value / other.value)

    def __eq__(self, other):
        return self.value == other.value


class TestMyInt(unittest.TestCase):
    def setUp(self):
        print("setup called")

    def tearDown(self):
        print("tearDown called")

    def testArith(self):
        self.assertEqual(MyInt(1) + MyInt(2), MyInt(3))
        self.assertEqual(MyInt(10) * MyInt(2), MyInt(30))

    def testComp(self):
        self.assertTrue(MyInt(1) + MyInt(2) == MyInt(3))

    def testConv(self):
        for i in range(100):
            self.assertEqual(MyInt(i).to_binary(), bin(i))

if __name__ == '__main__':
    unittest.main()

