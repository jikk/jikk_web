import re

txt = """
my email addresses 

kangkook-jee@hotmail.com

that's it!
"""
match = re.search(r'\w+@\w+', txt)
#match = re.search(r'[\w.-]+@[\w.-]+', str)
#match = re.search('([\w.-]+)@([\w.-]+)', str)
#match = re.finditer('([\w.-]+)@([\w.-]+)', str)
if match:
    print match.group()
