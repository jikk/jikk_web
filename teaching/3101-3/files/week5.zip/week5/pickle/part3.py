#!/usr/bin/env python
import csv
import sys


def get_farmers_dicts(fname):
    """
    @param string fname: filename
    @return (dict, dict): tuple for dictionaries of
        (zipcode_to_address, city_to_zipcode)

    """
    entries = []
    try:
        f = open(fname, 'r')
        creader = csv.reader(f)
        for entry in creader:
            entries.append(entry)
        f.close()
    except IOError:
        print >> sys.stderr, "file IO failed"
        raise

    #skipping the first line
    entries = entries[1:]
    
    #zip2addr
    zip2addr = {}

    for entry in entries:
        zipcode = entry[7]
        if zipcode not in zip2addr:
            zip2addr[zipcode] = [entry]
        else:
            zip2addr[zipcode].append(entry)

    #city2zip
    city2zip = {}
    for entry in entries:
        city = entry[4].title()
        if city not in city2zip:
            city2zip[city] = [entry[7]]
        else:
            city2zip[city].append(entry[7])

    return zip2addr, city2zip


def get_format_str(ent_lst):
    """
    @param list ent_lst: list of farmers market entries
    @return string: formatted string representation for farmers market
    """

    format_str = \
    """
    {0}
    {1}, {2}, {3}
    {4}"""
    for entry in ent_lst:
        return format_str.format(entry[1], entry[3], entry[4], entry[6], \
                                 entry[7])

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print >> sys.stderr, "Invalid usage: {0} csv_file".format(sys.argv[0])
        sys.exit()

    fname = sys.argv[1]
    zip2addr, city2zip = get_farmers_dicts(fname)

    while True:
        try:
            input = raw_input(">>")
        except EOFError:
            break

        if input.strip() == 'quit':
            break
        elif input.isdigit():

            try:
                addr_lst = zip2addr[input]
            except KeyError:
                print "Input not found: {0}".format(input)
                continue

            print get_format_str(addr_lst)
        else:
            try:
                zip_lst = city2zip[input]
            except KeyError:
                print "Input not found: {0}".format(input)
                continue

            for zipcode in zip_lst:
                print get_format_str(zip2addr[zipcode])

    print "going out..."


