print ("second __init__: {0} from {1}".format(__name__, __file__))
